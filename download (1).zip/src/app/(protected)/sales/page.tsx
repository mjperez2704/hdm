
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sales } from "@/components/sales";
import { QuotesManager } from "@/components/quotes-manager";
import { getVentas, getClientes, getProductos, getCoordenadas, getPresupuestos } from "@/lib/data";

export default async function SalesAndQuotesPage() {
  const sales = await getVentas();
  const clients = await getClientes();
  const products = await getProductos();
  const quotes = await getPresupuestos();
  const coordenadas = await getCoordenadas();

  return (
    <Tabs defaultValue="quotes">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="quotes">Presupuestos</TabsTrigger>
        <TabsTrigger value="sales">Ventas</TabsTrigger>
      </TabsList>
      <TabsContent value="quotes">
        <QuotesManager 
          initialQuotes={quotes} 
          clients={clients} 
          products={products} 
        />
      </TabsContent>
      <TabsContent value="sales">
        <Sales 
          initialSales={sales}
          clients={clients}
          products={products}
          coordenadas={coordenadas}
        />
      </TabsContent>
    </Tabs>
  );
}
