import { Quotes } from "@/components/quotes";

export default function QuotesPage() {
  return (
    <Quotes />
  );
}
