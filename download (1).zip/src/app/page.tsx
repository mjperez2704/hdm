
"use client";
import { redirect } from "next/navigation";

// The root page should always redirect to a useful page.
// In this case, we'll redirect to the login page if not authenticated,
// or the dashboard if authenticated. For simplicity, we just redirect to login
// and let the login page/session provider handle the rest.
export default function Home() {
  redirect("/login");
}
